﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Mail;
using System.Windows.Forms;
using MailKit;
using MailKit.Net.Imap;

using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Bai4
{
    public partial class Bai4 : Form
    {
        private MailKit.Net.Imap.ImapClient client; 

        public Bai4()
        {
            InitializeComponent();
            client = new MailKit.Net.Imap.ImapClient(); 
        }

        private void bt_Login_Click(object sender, EventArgs e)
        {
            bt_Login.Enabled = false;
            bt_Logout.Enabled = true;
            bt_newMail.Enabled = true;
            bt_Refresh.Enabled = true;
            try
            {
                
                string IMAP_SERVER = tb_imap.Text;
                int IMAP_PORT = Int32.Parse(cb_Port_imap.SelectedItem.ToString());
                string IMAP_USERNAME = tb_user.Text;
                string IMAP_PASSWORD = tb_pass.Text;

                client.Connect(IMAP_SERVER, IMAP_PORT, true);
                client.Authenticate(IMAP_USERNAME, IMAP_PASSWORD);

                load_dgv(sender,e);
            }
            catch (Exception ex)
            {
                client.Disconnect(true);
                bt_Logout.Enabled = false;
                bt_Refresh.Enabled = false;
                bt_newMail.Enabled = false;
                bt_Login.Enabled = true;
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message);
            }
        }
        private void load_dgv(object sender, EventArgs e)
        {
            dgv_Mail.Rows.Clear();
            var inbox = client.Inbox;

            inbox.Open(MailKit.FolderAccess.ReadOnly);
            for (int i = 0; i < inbox.Count; i++)
            {
                var message = inbox.GetMessage(i);
                dgv_Mail.Rows.Add((i + 1).ToString(), message.From, message.Subject, message.Date, message.TextBody);
            }
        }
        private void Bai4_Load(object sender, EventArgs e)
        {
            cb_Port_imap.Items.Clear();
            cb_Port_imap.Items.Add("993");
            cb_Port_Smtp.Items.Clear();
            cb_Port_Smtp.Items.Add("465");
            tb_imap.Text = "imap.gmail.com";
            tb_SMTP.Text = "smtp.gmail.com";
            cb_Port_imap.SelectedItem = "993";
            cb_Port_Smtp.SelectedItem = "465";
            bt_Logout.Enabled = false;
            bt_Refresh.Enabled = false;
            bt_newMail.Enabled = false;
            bt_Login.Enabled = true;
            dgv_Mail.Rows.Clear();
        }


        private void dgv_Mail_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                int rowIndex = e.RowIndex;
                string from = dgv_Mail.Rows[rowIndex].Cells["From"].Value.ToString();
                string subject = dgv_Mail.Rows[rowIndex].Cells["Subject"].Value.ToString();
                DateTimeOffset dateTimeOffset = (DateTimeOffset)dgv_Mail.Rows[rowIndex].Cells["DateTime"].Value;
                DateTime date = dateTimeOffset.DateTime;
                string body = dgv_Mail.Rows[rowIndex].Cells["Body"].Value.ToString();
                this.Hide();
                ReadMail readMail = new ReadMail();
                readMail.DisplayEmail(tb_user.Text, from, subject, date, body,tb_pass.Text);
                readMail.ShowDialog();
                readMail = null;
                this.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        private void bt_Refresh_Click(object sender, EventArgs e)
        {
            load_dgv(sender, e);
        }

        private void bt_newMail_Click(object sender, EventArgs e)
        {
            this.Hide();
            SendMail sendMail = new SendMail();
            sendMail.DisplayEmail(null, tb_user.Text, null, null, null, tb_pass.Text);
            sendMail.ShowDialog();
            sendMail = null;
            this.Show();
        }

        private void bt_Logout_Click(object sender, EventArgs e)
        {
            try
            {
                if (client.IsConnected)
                {
                    client.Disconnect(true);
                    MessageBox.Show("Đã đăng xuất");
                    Bai4_Load(sender, e);
                }
                else
                {
                    MessageBox.Show("Không có kết nối đến server");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message);
            }
        }


        private void tb_pass_TextChanged(object sender, EventArgs e)
        {
            System.Windows.Forms.TextBox textBox = (System.Windows.Forms.TextBox)sender;
            textBox.UseSystemPasswordChar = true;
        }
    }
}

